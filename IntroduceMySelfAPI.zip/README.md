초롱아빠가 대충 만든 API 서버.

React, Core, Redis, .Net 5
