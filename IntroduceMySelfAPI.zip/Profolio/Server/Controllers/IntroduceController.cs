using Microsoft.AspNetCore.Mvc;

using Profolio.Shared;

namespace Profolio.Server.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class IntroduceController : ControllerBase
	{
		private readonly ILogger<IntroduceController> _logger;

		public IntroduceController(ILogger<IntroduceController> logger)
		{
			_logger = logger;
		}

		[HttpGet]
		public async ValueTask<Introduce> Get()
		{
			HttpClient client = new HttpClient();
			return await client.GetFromJsonAsync<Introduce>("http://localhost:8080/IntroduceMySelf/Introduce?name=aa");
		}
	}
}