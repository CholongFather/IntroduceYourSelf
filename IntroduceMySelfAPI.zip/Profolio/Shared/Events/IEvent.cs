﻿namespace Profolio.Shared.Events;

public interface IEvent
{
}