namespace Profolio.Shared.Notifications;

public class StatsChangedNotification : INotificationMessage
{
}