﻿namespace Profolio.Shared.Notifications;

public interface INotificationMessage
{
}