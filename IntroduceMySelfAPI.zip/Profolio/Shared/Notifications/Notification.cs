﻿namespace Profolio.Shared.Notifications;

public class Notification : INotificationMessage
{
}