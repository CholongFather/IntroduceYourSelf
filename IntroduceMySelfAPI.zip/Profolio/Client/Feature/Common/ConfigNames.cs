﻿namespace Profolio.Client.Common;

public static class ConfigNames
{
	public const string ApiBaseUrl = "ApiBaseUrl";
	public const string ApiScope = "ApiScope";
}