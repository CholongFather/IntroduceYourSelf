﻿namespace Profolio.Client.Common;

public interface IAppService
{
}