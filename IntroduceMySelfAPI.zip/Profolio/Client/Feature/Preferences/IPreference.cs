﻿namespace Profolio.Client.Preferences;

public interface IPreference
{
}