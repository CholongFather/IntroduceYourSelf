﻿namespace Profolio.Client.Notifications;

public enum ConnectionState
{
    Connected,
    Connecting,
    Disconnected
}