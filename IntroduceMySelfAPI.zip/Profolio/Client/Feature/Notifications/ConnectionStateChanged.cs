﻿using Profolio.Shared.Notifications;

namespace Profolio.Client.Notifications;

public record ConnectionStateChanged(ConnectionState State, string? Message) : INotificationMessage;