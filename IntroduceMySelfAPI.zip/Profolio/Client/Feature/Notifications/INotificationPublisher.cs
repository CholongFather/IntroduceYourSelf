using Profolio.Shared.Notifications;

namespace Profolio.Client.Notifications;

public interface INotificationPublisher
{
    Task PublishAsync(INotificationMessage notification);
}