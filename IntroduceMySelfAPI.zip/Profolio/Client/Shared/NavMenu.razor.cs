﻿//using FSH.BlazorWebAssembly.Client.Infrastructure.Auth;
//using FSH.WebApi.Shared.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Components;
//using Microsoft.AspNetCore.Components.Authorization;

namespace Profolio.Client.Shared;

public partial class NavMenu
{
	//[CascadingParameter]
	//protected Task<AuthenticationState> AuthState { get; set; } = default!;
	[Inject]
	protected IAuthorizationService AuthService { get; set; } = default!;

	private string? _hangfireUrl;
	private bool _canViewHangfire;
	private bool _canViewDashboard;
	private bool _canViewRoles;
	private bool _canViewUsers;
	private bool _canViewProducts;
	private bool _canViewBrands;
	private bool _canViewTenants;
	private bool CanViewAdministrationGroup => _canViewUsers || _canViewRoles || _canViewTenants;

	protected override async Task OnParametersSetAsync()
	{
		//var user = (await AuthState).User;
		_hangfireUrl = "";
		_canViewHangfire = true;
		_canViewDashboard = true;
		_canViewRoles = true;
		_canViewUsers = true;
		_canViewProducts = true;
		_canViewBrands = true;
		_canViewTenants = true;
	}
}